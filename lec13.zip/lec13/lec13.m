% % %  ***********************************************************  
% % %  ***********************************************************  
% % %   Image Classification Using KNN
% % %   Lecture 13, October 6, 2021 
% % % 
% % %   Note: Images are taken from CIFAR-10
% % %   https://www.kaggle.com/fedesoriano/cifar10-python-in-csv
% % %  ***********************************************************    
% % %  ***********************************************************    
clc
clear
close all

nr_im = 150;
for i = 1:nr_im
    
    im = 0; %  ****************** Question ****************** Read each image located in tiny folder

    All(:,:,:,i) = im;                           % Save all of the imgs in All
end
All = reshape(All,size(All,1)*size(All,2)*size(All,3),nr_im);  % Change All into a matrix (each row = one img)
% save('TinyIms.mat', 'All', 'nr_im')

% Test to see what has happened...
% im = All(:,1);
% im = reshape(im,32,32,3);
% imshow(im)
%% Read the labels
fileID = fopen('tiny/labels.txt','r');  % Open the txt file for reading
chr = fscanf(fileID,'%c');              % Read data, '%c' = Read any single character
range = sscanf(chr,'%d');               % Convert chr to numbers, '%d' = integers
NrLabels = length(range)/2;

labels = 0; % ****************** Question ****************** Define a column vector of size nr_im and save the labels for each img/row in All

fclose(fileID)                          % Close the file
%% K-Fold Cross Validation
k = 5;
c = cvpartition(nr_im,'KFold',k);       % Define a random partition for k folds

idxTrain = training(c,1);               % Return the training indices for repetition i
idxTest = test(c,1);                    % Return the testing indices for repetition i
TestIDs = find(idxTest == 1);           % Find the acctual index values

nr_test = 0;  %****************** Question ****************** Find the total number of test data 
nr_train = 0; %****************** Question ****************** Find the total number of test data

testId = idxTestIDs(1);
testIm = All(:,testId);
dst = abs(All(:,idxTrain)-repmat(testIm,1,nr_train));   %Calculate the distance between all training imgs and the test img
dst = sum(dst);
[~,mnIdx] = mink(dst,k);                 % Find the k smallest elements
Allids = 1:nr_im;
vote = 0;      %****************** Question ****************** Find the most frequent value 
vote == labels(testId)                   % Check to see if you predicted the label correctly

